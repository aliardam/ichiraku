-- MySQL dump 10.13  Distrib 8.0.44, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: japanese_restaurant
-- ------------------------------------------------------
-- Server version	8.0.44

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `users` (
  `user_id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `email` varchar(100) DEFAULT NULL,
  `password` varchar(255) NOT NULL,
  `phone` varchar(20) DEFAULT NULL,
  `address` varchar(255) DEFAULT NULL,
  `role` varchar(20) NOT NULL DEFAULT 'user',
  PRIMARY KEY (`user_id`),
  UNIQUE KEY `email` (`email`),
  UNIQUE KEY `phone` (`phone`),
  CONSTRAINT `chk_email_or_phone` CHECK (((`email` is not null) or (`phone` is not null)))
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1,'John Leo','John@mail.com','scrypt:32768:8:1$k5XTUZVCfKooY5in$5784a12be9b4b7098336a1ad3ba397737b8fa6f76da5d5156d775ae25b11b719b4f2ae06ee2e823fcb3add05afd9aa9b853651cdaa33e46348d95f31ec9f60a4','','Jana Matejki','user'),(6,'Alex Gomes','alex25@gmail.com','scrypt:32768:8:1$87uetPbxNbX3DoGS$54d8e59ca391a69f8fc3465f34390a88ad2f1888ad47e8bf664857ae6ade3cdc55a24aaba228da0b0db54fb0647f86cd84767ee4e42539b2dde58dbbef2a43f8',NULL,'Jana Matejki','user'),(7,'Jacob','Jacob@mail.com','scrypt:32768:8:1$akAl6BfYtpGYLaWY$2cac2fabce59090eb5785eb163cc5332957aeabe83bb075221fe989c09bbdebbcce2287f48d00b09ecfa3087c7bac8695da0cd203115c197452324bac1afa739',NULL,'Jana','user'),(8,'Admin Ali','aliardam402@gmail.com','scrypt:32768:8:1$JRcbo23fanNnhebm$7d2b50959c354cb7c295084a3907632bbf9cbb100e79a19989a091f9ecdac38fba1433935e89de551c2c4e9464ce75c9ba400fa9b1976cde5e3d375d2382f05e','1234567890','Restaurant HQ','admin');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-12-10 22:55:43
