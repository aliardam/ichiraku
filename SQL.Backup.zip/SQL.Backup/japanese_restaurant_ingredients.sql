-- MySQL dump 10.13  Distrib 8.0.44, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: japanese_restaurant
-- ------------------------------------------------------
-- Server version	8.0.44

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `ingredients`
--

DROP TABLE IF EXISTS `ingredients`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `ingredients` (
  `ingredient_id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `allergen` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`ingredient_id`)
) ENGINE=InnoDB AUTO_INCREMENT=53 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ingredients`
--

LOCK TABLES `ingredients` WRITE;
/*!40000 ALTER TABLE `ingredients` DISABLE KEYS */;
INSERT INTO `ingredients` VALUES (1,'Soy Sauce','Soy'),(2,'Rice',NULL),(3,'Seaweed',NULL),(4,'Salmon','Fish'),(5,'Shrimp','Shellfish'),(6,'Egg','Egg'),(7,'Sugar',NULL),(8,'Flour','Gluten'),(9,'Milk','Dairy'),(10,'Matcha Powder',NULL),(11,'Tofu','Soy'),(12,'Chicken',NULL),(13,'Green Tea Leaves',NULL),(14,'Noodles','Gluten'),(15,'Red Bean Paste',NULL),(16,'Vegetable Oil',NULL),(17,'Dashi Broth','Fish'),(18,'Teriyaki Sauce','Soy'),(19,'Ice Cream','Dairy'),(20,'Carbonated Water',NULL),(21,'Sugar Syrup',NULL),(22,'Cream Cheese','Dairy'),(23,'Butter','Dairy'),(24,'Soy Sauce','Soy'),(25,'Rice',NULL),(26,'Seaweed',NULL),(27,'Salmon','Fish'),(28,'Shrimp','Shellfish'),(29,'Egg','Egg'),(30,'Sugar',NULL),(31,'Flour','Gluten'),(32,'Milk','Dairy'),(33,'Matcha Powder',NULL),(34,'Tofu','Soy'),(35,'Chicken',NULL),(36,'Green Tea Leaves',NULL),(37,'Noodles','Gluten'),(38,'Red Bean Paste',NULL),(39,'Vegetable Oil',NULL),(40,'Dashi Broth','Fish'),(41,'Teriyaki Sauce','Soy'),(42,'Ice Cream','Dairy'),(43,'Carbonated Water',NULL),(44,'Sugar Syrup',NULL),(45,'Cream Cheese','Dairy'),(46,'Butter','Dairy'),(47,'Crab Stick','Shellfish'),(48,'Avocado',NULL),(49,'Cucumber',NULL),(50,'Crab Stick','Shellfish'),(51,'Avocado',NULL),(52,'Cucumber',NULL);
/*!40000 ALTER TABLE `ingredients` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-12-10 22:55:43
